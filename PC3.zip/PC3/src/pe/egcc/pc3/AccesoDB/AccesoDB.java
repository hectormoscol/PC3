package pe.egcc.pc3.AccesoDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class AccesoDB {
	
	private AccesoDB(){
		}
	
	public static Connection getConnection(){
	    Connection cn = null;
	    
	    try {
	      // Parametros de conexion
	      String driver = "com.mysql.jdbc.Driver";
	      String urlDB = "jdbc:mysql://localhost:3306/eurekabank";
	      String user = "eureka";
	      String pass = "admin";
	      // Cargar el driver a memoria
	      Class.forName(driver).newInstance();
	      // Obtener el objeto Connection
	      cn = DriverManager.getConnection(urlDB, user, pass);
	    } catch (ClassNotFoundException e) {
	      throw new RuntimeException("No se encontro el driver");
	    } catch (SQLException e) {
	      throw new RuntimeException(e.getMessage());
	    } catch (Exception e) {
	      throw new RuntimeException("No se encontro el driver");
	    }
	    return cn;
	  }

}
