package pe.egcc.pc3.model;


public class Usuario {
	private String idempleado;
	  private String usuario;
	  private String clave;
	  private String estado;
	  
	 public Usuario(){
		 
	 }

	public String getIdempleado() {
		return idempleado;
	}

	public void setIdempleado(String idempleado) {
		this.idempleado = idempleado;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	 
	
	 
	 

}
