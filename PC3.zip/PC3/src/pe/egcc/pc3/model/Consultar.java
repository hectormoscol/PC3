package pe.egcc.pc3.model;

public class Consultar {
	
	private String ncuenta        ;
	private String moneda  ;
	private String saldo         ;
	private String nombre        ;
	private String apPaterno      ;
	private String apMaterno       ;
	private String sucursal        ;
	private String cuenEstado        ;
	
	
	public Consultar(){
		
	}


	public String getNcuenta() {
		return ncuenta;
	}


	public void setNcuenta(String ncuenta) {
		this.ncuenta = ncuenta;
	}


	public String getMoneda() {
		return moneda;
	}


	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}


	public String getSaldo() {
		return saldo;
	}


	public void setSaldo(String saldo) {
		this.saldo = saldo;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApPaterno() {
		return apPaterno;
	}


	public void setApPaterno(String apPaterno) {
		this.apPaterno = apPaterno;
	}


	public String getApMaterno() {
		return apMaterno;
	}


	public void setApMaterno(String apMaterno) {
		this.apMaterno = apMaterno;
	}


	public String getSucursal() {
		return sucursal;
	}


	public void setSucursal(String sucursal) {
		this.sucursal = sucursal;
	}


	public String getCuenEstado() {
		return cuenEstado;
	}


	public void setCuenEstado(String cuenEstado) {
		this.cuenEstado = cuenEstado;
	}


	
	
	


	
	

}
