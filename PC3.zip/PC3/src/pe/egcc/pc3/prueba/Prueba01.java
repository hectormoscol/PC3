package pe.egcc.pc3.prueba;
import java.sql.Connection;
import pe.egcc.pc3.AccesoDB.AccesoDB;

public class Prueba01 {
	
	public static void main(String[] args) {
		try {
		      Connection cn = AccesoDB.getConnection();
		      System.out.println("SALIO BIEN XD");
		      cn.close();
		      System.out.println("MASOMENOS");
		    } catch (Exception e) {
		      e.printStackTrace();
		    }
		  
	}
}

