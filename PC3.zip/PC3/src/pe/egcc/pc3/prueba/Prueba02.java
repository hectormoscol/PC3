package pe.egcc.pc3.prueba;
import pe.egcc.pc3.model.Usuario;
import pe.egcc.pc3.service.Logeo;

public class Prueba02 {
	public static void main(String[] args){
	    System.out.println("Pancho");
	    try {
	      // Datos
	      String usuario = "xjose";
	      String clave = "acosador";
	      // Proceso
	      Logeo logonService = new Logeo();
	      Usuario  user = logonService.validar(usuario, clave);
	      // Reporte
	      System.out.println("USUARIO: " + user.getUsuario());
	    } catch (Exception e) {
	      e.printStackTrace();
	    }
	  }

}
