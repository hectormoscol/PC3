package pe.egcc.pc3.prueba;

import pe.egcc.pc3.model.Consultar;
import pe.egcc.pc3.service.ConsultarCuenta;

public class Prueba03 {
	public static void main(String[] args) {
		try {
			String ncuenta="00100001";
			ConsultarCuenta servicio = new ConsultarCuenta();
			Consultar con = servicio.consulta(ncuenta);
			
			//Reporte
			System.out.println("NUMERO DE CUENTA: "+con.getNcuenta());
			System.out.println("MONEDA: "+con.getMoneda());
			System.out.println("SALDO: "+con.getSaldo());
			System.out.println("NOMBRE: "+con.getNombre()+", "+con.getApPaterno()+" "+con.getApMaterno());
			System.out.println("SUCURSAL: "+con.getSucursal());
			System.out.println("ESTADO: "+con.getCuenEstado());
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
