package pe.egcc.pc3.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import pe.egcc.pc3.AccesoDB.AccesoDB;
import pe.egcc.pc3.model.Consultar;

public class ConsultarCuenta {
	public Consultar consulta(String ncuenta){
		Connection cn = null;
		Consultar bean = null;
		try {
		      cn = AccesoDB.getConnection();
		      String sql = "select " 
		    		  + "chr_cuencodigo,"
		    		  + "vch_monedescripcion,"
		    		  + "dec_cuensaldo,"
		    		  + "vch_clienombre,"
		    		  + "vch_cliepaterno,"
		    		  + "vch_cliematerno,"
		    		  + "vch_sucunombre,"
		    		  + "vch_cuenestado "
		    		  + "from cuenta c inner join Moneda m on c.chr_monecodigo=m.chr_monecodigo " 
		    		  + "inner join Cliente cli on c.chr_cliecodigo=cli.chr_cliecodigo "
		    		  + "inner join Sucursal s on c.chr_sucucodigo=s.chr_sucucodigo "
		    		  + "where c.chr_cuencodigo=?";
		      PreparedStatement pstm = cn.prepareStatement(sql);
		      pstm.setString(1, ncuenta);

		      ResultSet rs = pstm.executeQuery();
		      if(rs.next()){
		        bean = new Consultar();
		        bean.setNcuenta(rs.getString("chr_cuencodigo"));
		        bean.setMoneda(rs.getString("vch_monedescripcion"));
		        bean.setSaldo(rs.getString("dec_cuensaldo"));
		        bean.setNombre(rs.getString("vch_clienombre"));
		        bean.setApPaterno(rs.getString("vch_cliepaterno"));
		        bean.setApMaterno(rs.getString("vch_cliematerno"));
		        bean.setSucursal(rs.getString("vch_sucunombre"));
		        bean.setCuenEstado(rs.getString("vch_cuenestado"));
		      }
		      rs.close();
		      pstm.close();
		    } catch (SQLException e) {
		      throw new RuntimeException(e.getMessage());
		    } catch (Exception e) {
		      throw new RuntimeException("DATOS ERRONEOS");
		    } finally{
		      try {
		        cn.close();
		      } catch (Exception e2) {
		      }
		    }
		    return bean;
	}

}
