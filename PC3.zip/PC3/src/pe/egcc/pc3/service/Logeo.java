package pe.egcc.pc3.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import pe.egcc.pc3.AccesoDB.AccesoDB;
import pe.egcc.pc3.model.Usuario;

public class Logeo {
	public Usuario validar(String usuario, String clave){
	    Connection cn = null;
	    Usuario bean = null;
	    try {
	      cn = AccesoDB.getConnection();
	      String sql = "select chr_emplcodigo, "
	          + "vch_emplusuario, vch_emplestado "
	          + "from Usuario "
	          + "where vch_emplusuario = ? "
	          + "and vch_emplclave = SHA(?) "
	          + "and vch_emplestado = 'ACTIVO'";
	      PreparedStatement pstm = cn.prepareStatement(sql);
	      pstm.setString(1, usuario);
	      pstm.setString(2, clave);
	      ResultSet rs = pstm.executeQuery();
	      if(rs.next()){
	        bean = new Usuario();
	        bean.setIdempleado(rs.getString("chr_emplcodigo"));
	        bean.setUsuario(rs.getString("vch_emplusuario"));
	        bean.setEstado(rs.getString("vch_emplestado"));
	      }
	      rs.close();
	      pstm.close();
	    } catch (SQLException e) {
	      throw new RuntimeException(e.getMessage());
	    } catch (Exception e) {
	      throw new RuntimeException("DATOS ERRONEOS");
	    } finally{
	      try {
	        cn.close();
	      } catch (Exception e2) {
	      }
	    }
	    return bean;
	  }

}
