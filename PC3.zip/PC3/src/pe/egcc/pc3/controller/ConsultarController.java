package pe.egcc.pc3.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pe.egcc.pc3.model.Consultar;
import pe.egcc.pc3.service.ConsultarCuenta;


/**
 * Servlet implementation class ConsultarController
 */
@WebServlet("/Consulta")
public class ConsultarController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String destino;
		//Datos
		String cod = request.getParameter("ncuenta");
		
		//Proceso
		try{
		ConsultarCuenta service = new ConsultarCuenta();
		Consultar bean = service.consulta(cod);
		
		if( bean == null ){
	          throw new Exception("DATOS ERRONEOS");
	        }
	        
	        destino = "consultar.jsp";
		}catch(Exception e){
			request.setAttribute("ERROR", e.getMessage());
			destino = "main.jsp";
		}
		UtilController.forward(request, response, destino);
	}

	

}
